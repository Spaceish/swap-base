def lol(fcked_your_sis):
    return "By SpaceDot"